package hu.montlikadani.tablist.utils.datafetcher;

public interface RequestType {

    hu.montlikadani.tablist.utils.PlayerSkinProperties get(String from) throws java.io.IOException;

}
