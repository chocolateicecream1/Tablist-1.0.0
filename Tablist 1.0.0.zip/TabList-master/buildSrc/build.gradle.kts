repositories {
	gradlePluginPortal()
}

plugins {
	`kotlin-dsl`
}
