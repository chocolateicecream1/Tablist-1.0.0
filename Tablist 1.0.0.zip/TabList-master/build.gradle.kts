plugins {
    id("java-library")
}

allprojects {
    apply(plugin = "java-library")
}
