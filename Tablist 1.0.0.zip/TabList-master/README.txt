Thank you for downloading my Tablist plugin!
I will be updating it every version :)

For further updates or information,
message me on discord. wrome. (with the period)
